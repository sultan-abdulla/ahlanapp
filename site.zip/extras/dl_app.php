
  <section class="about-the-app">
    <div class="container">
      <div class="row">
        <div class="col-md-5 col-lg-6">
          <img class="img-fluid" src="assets/images/mobile-app.png" alt="">
        </div>
        <div class="col-md-7 col-lg-6 download-app">
          <h2>Download the Bookit <br class="d-none d-lg-block"> app now!</h2>
          <p>Beauty and fitness should be quick, easy and <br class="d-none d-lg-block"> booked with a few taps</p>
          <a href="#"><img class="img-fluid logo" src="assets/images/appstore.png" alt=""></a>
          <a href="#"><img class="img-fluid logo" src="assets/images/gplay.png" alt=""></a>
        </div>
      </div>
    </div>
  </section>